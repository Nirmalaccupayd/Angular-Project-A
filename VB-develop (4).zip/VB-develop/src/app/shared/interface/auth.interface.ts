export interface ResponseInterface {
  message?: string;
  data?: any;
  status?: string;
  response_code?: string;
  response_message?: string;
}
