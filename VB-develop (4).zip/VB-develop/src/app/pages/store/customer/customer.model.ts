export class Customer {
  name? = "";
  retailer_ref_id? = "";
  mobile_number? = "";
  email = "";
  pan = "";
  retailer_name = "";
  company_name = "";
  dist_ref_id = "";
  dist_name = "";
  dist_company_name = "";
  location_ref_id = "";
  pincode = "";
  address1 = "";
  address2 = "";
  state = "";
  zone = "";
  zone_ref_id = "";
  service_master = {};
  category_master = {};
}
