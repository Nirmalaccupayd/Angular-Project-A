export const sweetalert2Config = {
  actions: "my-actions",
  cancelButton: "order-1 right-gap",
  confirmButton: "order-2",
};
