import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cards-ecommerce',
  templateUrl: './cards-ecommerce.component.html',
  styleUrls: ['./cards-ecommerce.component.scss']
})
export class CardsEcommerceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
